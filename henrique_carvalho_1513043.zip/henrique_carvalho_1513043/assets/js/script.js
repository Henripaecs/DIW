document.addEventListener('DOMContentLoaded', function() {
    const links = document.querySelectorAll('.secao li a');

    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            let offset = parseInt(link.getAttribute('data-offset'), 10);

            window.scrollTo({
                top: offset,
                behavior: 'smooth'
            });
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const username = 'Henripaecs'; 
    const token = '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'; 

    const headers = {
        'Authorization': `token ${token}`
    };

    fetch(`https://api.github.com/users/${username}/repos`, { headers })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar repositórios');
            }
            return response.json();
        })
        .then(data => {
            const reposContainer = document.getElementById('repos');
            reposContainer.innerHTML = ''; 
            data.forEach(repo => {
                const imageUrl = `https://raw.githubusercontent.com/${username}/${repo.name}/master/foto.png`;

                const repoElement = document.createElement('div');
                repoElement.classList.add('repo');
                repoElement.innerHTML = `
                    <h2>${repo.name}</h2>
                    <p>${repo.description || 'Sem descrição'}</p>
                    <img src="${imageUrl}" alt="Imagem do Repositório" style="max-width: 100%;">
                    <p><a href="#" id="repo_${repo.id}">Acessar Repositório</a></p>
                `;
                reposContainer.appendChild(repoElement);

                const repoLink = document.getElementById(`repo_${repo.id}`);
                repoLink.addEventListener('click', (event) => {
                    event.preventDefault(); 
                    window.location.href = `repo1.html?repo=${encodeURIComponent(repo.name)}`;
                });
            });
        })
        .catch(error => {
            console.error('Erro ao buscar repositórios:', error);
            const reposContainer = document.getElementById('repos');
            reposContainer.innerHTML = '<p>Não foi possível carregar os repositórios.</p>';
        });
});

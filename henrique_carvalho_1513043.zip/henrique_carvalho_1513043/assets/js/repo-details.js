document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const repoName = urlParams.get('repo');

    const repoDetailsContainer = document.getElementById('repo-details');
    const repoUrl = `https://api.github.com/repos/Henripaecs/${repoName}`;
    const readmeUrl = `https://api.github.com/repos/Henripaecs/${repoName}/readme`;

    
    fetch(repoUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar informações do repositório');
            }
            return response.json();
        })
        .then(repo => {
           
            repoDetailsContainer.innerHTML = `
                <h2>Detalhes do Repositório: ${repo.full_name}</h2>
                <p><strong>URL:</strong> <a href="${repo.html_url}" target="_blank">${repo.html_url}</a></p>
                <p><strong>Linguagem Principal:</strong> ${repo.language}</p>
                <p><strong>Número de Estrelas:</strong> ${repo.stargazers_count}</p>
                <p><strong>Criado em:</strong> ${new Date(repo.created_at).toLocaleDateString()}</p>
                <p><strong>Última atualização:</strong> ${new Date(repo.updated_at).toLocaleDateString()}</p>
            `;

            
            const imageUrl = `https://raw.githubusercontent.com/Henripaecs/${repoName}/master/foto.png`;

            
            const imageElement = document.createElement('img');
            imageElement.src = imageUrl;
            imageElement.classList.add('repo-image');

            
            repoDetailsContainer.appendChild(imageElement);
        })
        .catch(error => {
            console.error('Erro ao buscar informações do repositório:', error);
            repoDetailsContainer.innerHTML = '<p>Não foi possível carregar as informações do repositório.</p>';
        });
});
